backend/scripts/backup.sh: line 33: pg_dump: command not found
